﻿namespace BurgerResturentBuilderDesignPattern
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Burger burger = new BurgerBuilder().Id(01).Name("Italian Burger").Type("Chicken").Price(2500.00).Build();
            burger.Display();
        }
    }
}