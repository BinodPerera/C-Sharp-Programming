﻿using System;
namespace BurgerResturentBuilderDesignPattern
{
	public class Burger
	{
		private int id { get; set; }
        private string name { get; set; }
        private string type { get; set; }
		private double price { get; set; }

		public Burger(BurgerBuilder burgerBuilder)
		{
			id = burgerBuilder._id;
			name = burgerBuilder._name;
			type = burgerBuilder._type;
			price = burgerBuilder._price;

        }

		public void Display()
		{
			Console.WriteLine(id + " \n" + name + " \n" + type + " \n" + price);
		}
	}
}

