﻿using System;
namespace BurgerResturentBuilderDesignPattern
{
	public class BurgerBuilder
	{
		public int _id { get; set; }
		public string _name { get; set; }
		public string _type { get; set; }
		public double _price { get; set; }

		public BurgerBuilder Id(int id)
		{
			_id = id;
			return this;
		}

		public BurgerBuilder Name(string name)
		{
			_name = name;
			return this;
		}

		public BurgerBuilder Type(string type)
		{
			_type = type;
			return this;
		}

		public BurgerBuilder Price(double price)
		{
			_price = price;
			return this;
		}

		public Burger Build()
		{
			return new Burger(this);
		}
	}
}

