﻿using System;
namespace BuilderDesignPattern
{
	public class CarBuilder
	{

		public int _id { get; set; }
		public string _model { get; set; }
		public string _brand { get; set; }
		public double _price { get; set; }

		public CarBuilder Id(int id)
		{
			_id = id;
			return this;
		}

		public CarBuilder Model(string model)
		{
			_model = model;
			return this;
		}

		public CarBuilder Brand(string brand)
		{
			_brand = brand;
			return this;
		}

		public CarBuilder Price(double price)
		{
			_price = price;
			return this;
		}

		public Car Build()
		{
			return new Car(this);
		}
	}
}

