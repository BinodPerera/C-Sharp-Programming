﻿using System;
namespace BuilderDesignPattern
{
	public class Car
	{
        private int _id { get; set; }
        private string _model { get; set; }
        private string _brand { get; set; }
        private double _price { get; set; }

        public Car(CarBuilder carBuilder)
        {
            _id = carBuilder._id;
            _model = carBuilder._model;
            _brand = carBuilder._brand;
            _price = carBuilder._price;
        }

        public void DisplayCarInfo()
        {
            Console.WriteLine("\nCar info,");
            Console.WriteLine("Id: " + _id + "\nModel " + _model + "\nBrand: " + _brand + "\nPrice: " + _price);
        }
    }
}

