﻿using System;
namespace BuilderDesignPattern
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Car supra = new CarBuilder().Id(01).Model("Supra MK4").Price(14000000.00).Brand("TOYOTA").Build();
            supra.DisplayCarInfo();

            Car r34 = new CarBuilder().Id(02).Model("GTR R34").Price(24000000.00).Brand("NISSAN").Build();
            r34.DisplayCarInfo();
        }
    }
}